# ME Alerts (Android)

Checks https://monitor-the-situation.com/middle-east in the background and sends a phone
notification when a new story matches your escalation keywords.

- Urgent keywords (mobilization, reservists, sirens, ballistic, nuclear, "preparing for war"…) → loud heads-up alert
- Normal keywords (strike, attack, missile, drone, IDF, IRGC, Hezbollah, Houthi…) → standard alert
- Tap a notification to open the story. Keywords, interval and "alert on every Conflict event" are editable in the app.
- The first check only saves a baseline, so you aren't flooded with old stories.

## Get the APK without installing anything (GitHub)
1. Create a new GitHub repository and upload the contents of this folder (including the hidden `.github` folder).
2. Open the **Actions** tab; the "Build APK" workflow runs automatically (~4 min).
3. Open the finished run, download the **ME-Alerts-apk** artifact, unzip it, copy `app-debug.apk` to your phone and install it
   (allow "Install unknown apps" for your browser/file manager when asked).

## Or build with Android Studio
Open this folder in Android Studio → let Gradle sync → **Build > Build App Bundle(s) / APK(s) > Build APK(s)**,
or plug in your phone and press Run.

## After installing
1. Allow notifications when asked, then tap **Test alert**.
2. Tap **Battery optimization settings** and set ME Alerts to "Don't optimize"/"Unrestricted" so checks aren't delayed.
   On Samsung/Xiaomi/Huawei also allow background activity / autostart.

## Limits
- Android only allows background checks every 15 minutes at most; in deep sleep they can be delayed.
- The app reads the public web page. If the site changes its layout, the status line will show
  "No stories found", and the parser in `FeedFetcher.kt` needs updating.

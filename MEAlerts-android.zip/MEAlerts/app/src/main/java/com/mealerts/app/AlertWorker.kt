package com.mealerts.app

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

class AlertWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        return try {
            Checker.run(applicationContext)
            Result.success()
        } catch (e: Exception) {
            // Error is recorded in Prefs; the next periodic run will try again.
            Result.success()
        }
    }
}

object Scheduler {
    private const val WORK_NAME = "mts_poll"

    fun schedule(c: Context, minutes: Long, replace: Boolean) {
        val req = PeriodicWorkRequestBuilder<AlertWorker>(minutes.coerceAtLeast(15L), TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(c).enqueueUniquePeriodicWork(
            WORK_NAME,
            if (replace) ExistingPeriodicWorkPolicy.UPDATE else ExistingPeriodicWorkPolicy.KEEP,
            req
        )
    }

    fun cancel(c: Context) {
        WorkManager.getInstance(c).cancelUniqueWork(WORK_NAME)
    }
}

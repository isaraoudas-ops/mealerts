package com.mealerts.app

import android.annotation.SuppressLint
import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.card.MaterialCardView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AlertAdapter(
    private val onOpen: (HistoryEntry) -> Unit,
    private val onShare: (HistoryEntry) -> Unit,
) : RecyclerView.Adapter<AlertAdapter.VH>() {

    private var items: List<HistoryEntry> = emptyList()
    private val fmt = SimpleDateFormat("d MMM yyyy, HH:mm", Locale.getDefault())
    private val severity = Regex("""S\d""")

    @SuppressLint("NotifyDataSetChanged")
    fun submit(list: List<HistoryEntry>) {
        items = list
        notifyDataSetChanged()
    }

    override fun getItemCount() = items.size

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val card = v as MaterialCardView
        val icon: ImageView = v.findViewById(R.id.ivIcon)
        val badge: TextView = v.findViewById(R.id.tvBadge)
        val title: TextView = v.findViewById(R.id.tvTitle)
        val summary: TextView = v.findViewById(R.id.tvSummary)
        val meta: TextView = v.findViewById(R.id.tvMeta)
        val hits: TextView = v.findViewById(R.id.tvHits)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_alert, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val e = items[position]
        val ctx = h.itemView.context

        val parts = e.meta.split("·").map { it.trim() }.filter { it.isNotEmpty() && !severity.matches(it) }
        val category = parts.getOrNull(0).orEmpty()
        val location = parts.drop(1).joinToString(", ")

        val color = ContextCompat.getColor(
            ctx,
            when {
                e.urgent -> R.color.red
                category.equals("conflict", ignoreCase = true) -> R.color.amber
                else -> R.color.slate
            }
        )

        h.icon.backgroundTintList = ColorStateList.valueOf(ColorUtils.setAlphaComponent(color, 48))
        h.icon.imageTintList = ColorStateList.valueOf(color)

        h.badge.text = when {
            e.urgent -> "URGENT"
            category.isNotEmpty() -> category.uppercase(Locale.getDefault())
            else -> "REPORT"
        }
        h.badge.setTextColor(color)
        h.badge.backgroundTintList = ColorStateList.valueOf(ColorUtils.setAlphaComponent(color, 40))

        h.title.text = e.title
        h.summary.text = e.summary
        h.summary.isVisible = e.summary.isNotEmpty()

        h.meta.text = listOf(fmt.format(Date(e.time)), location).filter { it.isNotEmpty() }.joinToString("  ·  ")
        h.hits.text = "Matched: ${e.hits}"

        h.card.strokeColor = if (e.urgent) ColorUtils.setAlphaComponent(color, 140)
        else ContextCompat.getColor(ctx, R.color.stroke)

        h.card.setOnClickListener { onOpen(e) }
        h.card.setOnLongClickListener { onShare(e); true }
    }
}

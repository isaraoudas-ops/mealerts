package com.mealerts.app

import android.content.Context

object Checker {
    data class Outcome(val parsed: Int, val fresh: Int, val matched: Int, val firstRun: Boolean)

    @Synchronized
    fun run(c: Context): Outcome {
        val now = System.currentTimeMillis()
        try {
            val items = FeedFetcher.fetch()
            if (items.isEmpty()) {
                throw IllegalStateException("No stories found on the page (site layout may have changed)")
            }
            val seen = Prefs.seenIds(c).toHashSet()
            val firstRun = seen.isEmpty()
            val fresh = items.filter { it.id !in seen }

            val normal = Matcher.compile(Prefs.parseList(Prefs.keywordsRaw(c)))
            val urgent = Matcher.compile(Prefs.parseList(Prefs.urgentRaw(c)))
            val allConflict = Prefs.alertAllConflict(c)

            val entries = fresh.mapNotNull { item ->
                Matcher.match(item, normal, urgent, allConflict)?.let { m ->
                    HistoryEntry(item.id, item.title, item.url, item.summary, now, m.urgent, m.hits.joinToString(", "), item.meta)
                }
            }

            Prefs.addSeen(c, fresh.map { it.id })
            if (entries.isNotEmpty()) Prefs.addHistory(c, entries)

            // First run only records a baseline, so you aren't flooded with old stories.
            if (!firstRun && entries.isNotEmpty()) {
                Notifier.createChannels(c)
                entries.take(10).asReversed().forEach { Notifier.show(c, it) }
            }
            Prefs.setStatus(c, now, null)
            return Outcome(items.size, fresh.size, entries.size, firstRun)
        } catch (e: Exception) {
            Prefs.setStatus(c, now, e.message ?: e.javaClass.simpleName)
            throw e
        }
    }
}

package com.mealerts.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

object Notifier {
    private const val CH_URGENT = "urgent_v1"
    private const val CH_NORMAL = "normal_v1"

    fun createChannels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(CH_URGENT, "Urgent escalation alerts", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "War preparation, mobilization, sirens, ballistic/nuclear threats"
                enableVibration(true)
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_NORMAL, "Conflict news alerts", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Strikes, attacks, clashes and other matching news"
            }
        )
    }

    fun canPost(c: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun show(c: Context, e: HistoryEntry) {
        if (!canPost(c)) return
        val open = Intent(Intent.ACTION_VIEW, Uri.parse(e.url))
        val pi = PendingIntent.getActivity(
            c, e.id.hashCode(), open,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val body = if (e.summary.isNotEmpty()) e.summary else "Matched: ${e.hits}"
        val n = NotificationCompat.Builder(c, if (e.urgent) CH_URGENT else CH_NORMAL)
            .setSmallIcon(R.drawable.ic_stat_alert)
            .setContentTitle((if (e.urgent) "⚠ " else "") + e.title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText("$body\n\nMatched: ${e.hits}"))
            .setPriority(if (e.urgent) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setWhen(e.time)
            .setShowWhen(true)
            .build()
        try {
            NotificationManagerCompat.from(c).notify(e.id.hashCode(), n)
        } catch (_: SecurityException) {
        }
    }
}

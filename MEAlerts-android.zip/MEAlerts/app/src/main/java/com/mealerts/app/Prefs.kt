package com.mealerts.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class HistoryEntry(
    val id: String,
    val title: String,
    val url: String,
    val summary: String,
    val time: Long,
    val urgent: Boolean,
    val hits: String,
)

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("me_alerts", Context.MODE_PRIVATE)

    const val DEFAULT_URGENT =
        "mobiliz*, mobilis*, reservist*, call-up, siren*, air raid*, ballistic, nuclear, " +
        "invasion, invade*, declare* war, declaration of war, preparing for war, prepare* for war, " +
        "state of emergency, home front command, high alert, full-scale, ground operation, " +
        "evacuat*, bomb shelter*, war cabinet, all-out war"

    const val DEFAULT_KEYWORDS =
        "strike*, airstrike*, air strike*, attack*, missile*, rocket*, drone*, explosion*, blast*, " +
        "clash*, shelling, raid*, intercept*, killed, troops, military, war, warn*, threat*, " +
        "escalat*, offensive, deploy*, carrier, bomber*, mines, tanker*, idf, irgc, hezbollah, " +
        "hamas, houthi*, ansarallah, retaliat*, ceasefire"

    fun parseList(raw: String): List<String> =
        raw.split(',', '\n').map { it.trim().lowercase() }.filter { it.removeSuffix("*").length >= 2 }.distinct()

    fun enabled(c: Context) = sp(c).getBoolean("enabled", true)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    fun intervalMin(c: Context) = sp(c).getLong("interval", 15L)
    fun setIntervalMin(c: Context, v: Long) = sp(c).edit().putLong("interval", v).apply()

    fun keywordsRaw(c: Context) = sp(c).getString("keywords", DEFAULT_KEYWORDS) ?: DEFAULT_KEYWORDS
    fun urgentRaw(c: Context) = sp(c).getString("urgent", DEFAULT_URGENT) ?: DEFAULT_URGENT
    fun alertAllConflict(c: Context) = sp(c).getBoolean("all_conflict", false)

    fun saveFilters(c: Context, keywords: String, urgent: String, allConflict: Boolean) {
        sp(c).edit()
            .putString("keywords", keywords)
            .putString("urgent", urgent)
            .putBoolean("all_conflict", allConflict)
            .apply()
    }

    fun seenIds(c: Context): List<String> =
        (sp(c).getString("seen", "") ?: "").split('\n').filter { it.isNotEmpty() }

    fun addSeen(c: Context, ids: List<String>) {
        if (ids.isEmpty()) return
        val all = (seenIds(c) + ids).distinct().takeLast(1000)
        sp(c).edit().putString("seen", all.joinToString("\n")).commit()
    }

    fun history(c: Context): List<HistoryEntry> {
        val raw = sp(c).getString("history", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                HistoryEntry(
                    o.optString("id"), o.optString("title"), o.optString("url"),
                    o.optString("summary"), o.optLong("time"), o.optBoolean("urgent"),
                    o.optString("hits"),
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun addHistory(c: Context, entries: List<HistoryEntry>) {
        val merged = (entries + history(c)).distinctBy { it.id }.take(100)
        val arr = JSONArray()
        merged.forEach { e ->
            arr.put(
                JSONObject()
                    .put("id", e.id).put("title", e.title).put("url", e.url)
                    .put("summary", e.summary).put("time", e.time)
                    .put("urgent", e.urgent).put("hits", e.hits)
            )
        }
        sp(c).edit().putString("history", arr.toString()).commit()
    }

    fun lastCheck(c: Context) = sp(c).getLong("last_check", 0L)
    fun lastError(c: Context): String? = sp(c).getString("last_error", null)

    fun setStatus(c: Context, time: Long, error: String?) {
        sp(c).edit().putLong("last_check", time).putString("last_error", error).commit()
    }
}

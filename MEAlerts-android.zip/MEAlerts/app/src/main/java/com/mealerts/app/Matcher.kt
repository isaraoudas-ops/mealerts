package com.mealerts.app

object Matcher {
    class Rule(val label: String, val regex: Regex)
    data class Result(val urgent: Boolean, val hits: List<String>)

    private val CONFLICT = Regex("""·\s*conflict\b""", RegexOption.IGNORE_CASE)

    fun compile(words: List<String>): List<Rule> = words.map { w ->
        val pattern = if (w.endsWith("*")) {
            "\\b" + Regex.escape(w.removeSuffix("*").trim())
        } else {
            "\\b" + Regex.escape(w) + "\\b"
        }
        Rule(w, Regex(pattern, RegexOption.IGNORE_CASE))
    }

    fun match(item: FeedItem, normal: List<Rule>, urgent: List<Rule>, allConflict: Boolean): Result? {
        val text = item.title + " " + item.summary
        val u = urgent.filter { it.regex.containsMatchIn(text) }.map { it.label }
        val n = normal.filter { it.regex.containsMatchIn(text) }.map { it.label }
        val conflict = allConflict && CONFLICT.containsMatchIn(item.summary)
        if (u.isEmpty() && n.isEmpty() && !conflict) return null
        val hits = (u + n).ifEmpty { listOf("conflict event") }
        return Result(u.isNotEmpty(), hits)
    }
}

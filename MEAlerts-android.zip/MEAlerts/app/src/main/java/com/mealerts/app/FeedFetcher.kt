package com.mealerts.app

import org.jsoup.Jsoup

data class FeedItem(val id: String, val url: String, val title: String, val summary: String)

/**
 * Reads the public Middle East page and extracts story links of the form
 * https://monitor-the-situation.com/middle-east/<slug>-<8 hex chars>
 */
object FeedFetcher {
    const val FEED_URL = "https://monitor-the-situation.com/middle-east"

    private val STORY = Regex("""^https://monitor-the-situation\.com/middle-east/([a-z0-9-]+-[0-9a-f]{6,})$""")

    fun fetch(): List<FeedItem> {
        val doc = Jsoup.connect(FEED_URL)
            .userAgent("Mozilla/5.0 (Linux; Android) MEAlerts/1.0")
            .timeout(25_000)
            .maxBodySize(0)
            .get()

        val out = LinkedHashMap<String, FeedItem>()
        for (a in doc.select("a[href]")) {
            val href = a.absUrl("href").substringBefore('#').substringBefore('?').trimEnd('/')
            val id = STORY.matchEntire(href)?.groupValues?.get(1) ?: continue
            if (out.containsKey(id)) continue
            val title = a.text().trim()
            if (title.isEmpty()) continue

            // The surrounding list item carries "— S3 · Conflict · place · 2h ago. Summary…"
            val container = a.parents().firstOrNull { it.tagName() == "li" } ?: a.parent()
            var summary = container?.text()?.trim().orEmpty()
            if (summary.length > 600) summary = ""
            summary = summary.removePrefix(title).trim().trimStart('—', '–', '-', ' ').trim()

            out[id] = FeedItem(id, href, title, summary)
        }
        return out.values.toList()
    }
}

package com.mealerts.app

import org.jsoup.Jsoup

/** meta = "S3 · Conflict · Strait of Hormuz", summary = the descriptive text. */
data class FeedItem(val id: String, val url: String, val title: String, val summary: String, val meta: String)

/**
 * Reads the public Middle East page and extracts story links of the form
 * https://monitor-the-situation.com/middle-east/<slug>-<hex id>
 */
object FeedFetcher {
    const val FEED_URL = "https://monitor-the-situation.com/middle-east"

    private val STORY = Regex("""^https://monitor-the-situation\.com/middle-east/([a-z0-9-]+-[0-9a-f]{6,})$""")
    private val AGO = Regex("""(?:·\s*)?\b\d+\s*[a-zA-Z]{1,7}\s+ago\b\.?""")

    fun fetch(): List<FeedItem> {
        val doc = Jsoup.connect(FEED_URL)
            .userAgent("Mozilla/5.0 (Linux; Android) MEAlerts/2.0")
            .timeout(25_000)
            .maxBodySize(0)
            .get()

        val out = LinkedHashMap<String, FeedItem>()
        for (a in doc.select("a[href]")) {
            val href = a.absUrl("href").substringBefore('#').substringBefore('?').trimEnd('/')
            val id = STORY.matchEntire(href)?.groupValues?.get(1) ?: continue
            if (out.containsKey(id)) continue
            val title = a.text().trim()
            if (title.isEmpty()) continue

            val container = a.parents().firstOrNull { it.tagName() == "li" } ?: a.parent()
            var rest = container?.text()?.trim().orEmpty()
            if (rest.length > 800) rest = ""
            rest = rest.removePrefix(title).trim().trimStart('—', '–', '-', ' ').trim()

            val (meta, summary) = split(rest)
            out[id] = FeedItem(id, href, title, summary, meta)
        }
        return out.values.toList()
    }

    /** "S3 · Conflict · Place · 48m ago. Text…" → ("S3 · Conflict · Place", "Text…") */
    fun split(raw: String): Pair<String, String> {
        val m = AGO.find(raw) ?: return "" to raw
        val meta = raw.substring(0, m.range.first).trim().trimEnd('·').trim()
        val summary = raw.substring(m.range.last + 1).trim()
        return meta to summary
    }
}

package com.mealerts.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.format.DateUtils
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.ChipGroup
import com.google.android.material.progressindicator.LinearProgressIndicator
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var statusDot: View
    private lateinit var tvStatus: TextView
    private lateinit var tvLast: TextView
    private lateinit var tvError: TextView
    private lateinit var tvCount: TextView
    private lateinit var tvEmpty: TextView
    private lateinit var btnCheck: MaterialButton
    private lateinit var progress: LinearProgressIndicator
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var adapter: AlertAdapter

    private var urgentOnly = false
    private var checking = false

    private val askNotif =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (!granted) toast("Notifications are blocked, so alerts can't appear")
            refresh()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById<MaterialToolbar>(R.id.toolbar))
        supportActionBar?.setDisplayShowTitleEnabled(false)
        Notifier.createChannels(this)

        statusDot = findViewById(R.id.statusDot)
        tvStatus = findViewById(R.id.tvStatus)
        tvLast = findViewById(R.id.tvLast)
        tvError = findViewById(R.id.tvError)
        tvCount = findViewById(R.id.tvCount)
        tvEmpty = findViewById(R.id.tvEmpty)
        btnCheck = findViewById(R.id.btnCheck)
        progress = findViewById(R.id.progress)
        swipe = findViewById(R.id.swipe)

        adapter = AlertAdapter(onOpen = { openUrl(it.url) }, onShare = { share(it) })
        findViewById<RecyclerView>(R.id.rv).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        swipe.setColorSchemeColors(ContextCompat.getColor(this, R.color.red))
        swipe.setProgressBackgroundColorSchemeColor(ContextCompat.getColor(this, R.color.surface2))
        swipe.setOnRefreshListener { checkNow() }
        btnCheck.setOnClickListener { checkNow() }

        findViewById<ChipGroup>(R.id.chips).setOnCheckedStateChangeListener { _, ids ->
            urgentOnly = ids.contains(R.id.chipUrgent)
            refreshList()
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            askNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        if (Prefs.enabled(this)) {
            Scheduler.schedule(this, Prefs.intervalMin(this), replace = false)
            if (Prefs.lastCheck(this) == 0L) checkNow()
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_settings) {
            startActivity(Intent(this, SettingsActivity::class.java))
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun checkNow() {
        if (checking) return
        checking = true
        btnCheck.isEnabled = false
        btnCheck.text = "Checking…"
        progress.isVisible = true
        thread {
            val msg = try {
                val o = Checker.run(applicationContext)
                when {
                    o.firstRun -> "Baseline saved (${o.parsed} stories). You'll be alerted about new ones from now on."
                    o.matched > 0 -> "${o.matched} new matching alert(s)"
                    o.fresh > 0 -> "${o.fresh} new stories, none matched your keywords"
                    else -> "No new stories"
                }
            } catch (e: Exception) {
                "Check failed: ${e.message}"
            }
            runOnUiThread {
                if (!isDestroyed) {
                    checking = false
                    btnCheck.isEnabled = true
                    btnCheck.text = "Check now"
                    progress.isVisible = false
                    swipe.isRefreshing = false
                    toast(msg)
                    refresh()
                }
            }
        }
    }

    private fun refresh() {
        val on = Prefs.enabled(this)
        statusDot.backgroundTintList = ColorStateList.valueOf(
            ContextCompat.getColor(this, if (on) R.color.green else R.color.slate)
        )
        tvStatus.text = if (on) "Monitoring · every ${formatInterval(Prefs.intervalMin(this))}" else "Monitoring paused"

        val last = Prefs.lastCheck(this)
        tvLast.text = if (last == 0L) "Not checked yet"
        else "Last check ${DateUtils.getRelativeTimeSpanString(last, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS)}"

        val problems = mutableListOf<String>()
        Prefs.lastError(this)?.let { problems += it }
        if (!Notifier.canPost(this)) problems += "Notifications are turned off for this app"
        tvError.text = problems.joinToString("\n")
        tvError.isVisible = problems.isNotEmpty()

        refreshList()
    }

    private fun refreshList() {
        val all = Prefs.history(this)
        val shown = if (urgentOnly) all.filter { it.urgent } else all
        adapter.submit(shown)
        tvCount.text = if (urgentOnly) "Urgent (${shown.size})" else "Alerts (${shown.size})"
        tvEmpty.text = if (urgentOnly) "No urgent alerts recorded." else "No matching alerts yet.\nPull down or tap Check now."
        tvEmpty.isVisible = shown.isEmpty()
    }

    private fun formatInterval(min: Long) = if (min < 60) "$min min" else "${min / 60} h"

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            toast("No browser found")
        }
    }

    private fun share(e: HistoryEntry) {
        val text = buildString {
            append(e.title)
            if (e.summary.isNotEmpty()) append("\n\n").append(e.summary)
            append("\n\n").append(e.url)
        }
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        startActivity(Intent.createChooser(send, "Share alert"))
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}

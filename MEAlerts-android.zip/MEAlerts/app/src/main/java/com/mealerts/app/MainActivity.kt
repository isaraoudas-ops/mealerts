package com.mealerts.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.format.DateUtils
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private val intervals = longArrayOf(15, 30, 60, 120)

    private lateinit var swEnabled: SwitchCompat
    private lateinit var tvStatus: TextView
    private lateinit var spInterval: Spinner
    private lateinit var etKeywords: EditText
    private lateinit var etUrgent: EditText
    private lateinit var cbConflict: CheckBox
    private lateinit var btnCheck: Button
    private lateinit var listHistory: LinearLayout

    private val askNotif =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (!granted) toast("Notifications are blocked, so alerts can't appear")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Notifier.createChannels(this)

        swEnabled = findViewById(R.id.swEnabled)
        tvStatus = findViewById(R.id.tvStatus)
        spInterval = findViewById(R.id.spInterval)
        etKeywords = findViewById(R.id.etKeywords)
        etUrgent = findViewById(R.id.etUrgent)
        cbConflict = findViewById(R.id.cbConflict)
        btnCheck = findViewById(R.id.btnCheck)
        listHistory = findViewById(R.id.listHistory)

        spInterval.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            intervals.map { if (it < 60) "Every $it minutes" else "Every ${it / 60} hour(s)" }
        )
        loadSettings()

        swEnabled.setOnCheckedChangeListener { _, on ->
            Prefs.setEnabled(this, on)
            if (on) Scheduler.schedule(this, Prefs.intervalMin(this), replace = true) else Scheduler.cancel(this)
            refresh()
        }

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            Prefs.saveFilters(this, etKeywords.text.toString(), etUrgent.text.toString(), cbConflict.isChecked)
            Prefs.setIntervalMin(this, intervals[spInterval.selectedItemPosition])
            if (Prefs.enabled(this)) Scheduler.schedule(this, Prefs.intervalMin(this), replace = true)
            toast("Saved")
            refresh()
        }

        findViewById<Button>(R.id.btnReset).setOnClickListener {
            etKeywords.setText(Prefs.DEFAULT_KEYWORDS)
            etUrgent.setText(Prefs.DEFAULT_URGENT)
            toast("Defaults restored. Tap Save to keep them")
        }

        btnCheck.setOnClickListener { checkNow() }

        findViewById<Button>(R.id.btnTest).setOnClickListener {
            if (!Notifier.canPost(this)) {
                requestNotifPermission(); return@setOnClickListener
            }
            Notifier.show(
                this,
                HistoryEntry(
                    "test-alert", "Test alert: notifications are working", FeedFetcher.FEED_URL,
                    "This is what an urgent alert looks like. Tap to open the live map.",
                    System.currentTimeMillis(), true, "test"
                )
            )
        }

        findViewById<Button>(R.id.btnBattery).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }

        findViewById<Button>(R.id.btnOpenSite).setOnClickListener { openUrl(FeedFetcher.FEED_URL) }

        requestNotifPermission()
        if (Prefs.enabled(this)) {
            Scheduler.schedule(this, Prefs.intervalMin(this), replace = false)
            if (Prefs.lastCheck(this) == 0L) checkNow()
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun loadSettings() {
        swEnabled.isChecked = Prefs.enabled(this)
        etKeywords.setText(Prefs.keywordsRaw(this))
        etUrgent.setText(Prefs.urgentRaw(this))
        cbConflict.isChecked = Prefs.alertAllConflict(this)
        val idx = intervals.indexOf(Prefs.intervalMin(this))
        spInterval.setSelection(if (idx >= 0) idx else 0)
    }

    private fun requestNotifPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            askNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun checkNow() {
        btnCheck.isEnabled = false
        tvStatus.text = "Checking…"
        thread {
            val msg = try {
                val o = Checker.run(applicationContext)
                val base = "Read ${o.parsed} stories, ${o.fresh} new, ${o.matched} matched"
                if (o.firstRun) "$base. First check saves a baseline; alerts start from the next new story." else base
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
            runOnUiThread {
                if (!isDestroyed) {
                    btnCheck.isEnabled = true
                    toast(msg)
                    refresh()
                }
            }
        }
    }

    private fun refresh() {
        val last = Prefs.lastCheck(this)
        val err = Prefs.lastError(this)
        tvStatus.text = buildString {
            append(if (Prefs.enabled(this@MainActivity)) "Monitoring ON, every ${Prefs.intervalMin(this@MainActivity)} min" else "Monitoring OFF")
            append("\nLast check: ")
            append(if (last == 0L) "never" else DateUtils.getRelativeTimeSpanString(last))
            if (err != null) append("\nLast error: $err")
            if (!Notifier.canPost(this@MainActivity)) append("\nNotifications are not allowed for this app")
        }

        listHistory.removeAllViews()
        val pad = (10 * resources.displayMetrics.density).toInt()
        val history = Prefs.history(this)
        if (history.isEmpty()) {
            listHistory.addView(TextView(this).apply {
                text = "No matching stories yet."
                setPadding(0, pad, 0, pad)
            })
        }
        history.forEach { e ->
            listHistory.addView(TextView(this).apply {
                text = buildString {
                    if (e.urgent) append("⚠ ")
                    append(e.title)
                    append("\n")
                    append(DateUtils.getRelativeTimeSpanString(e.time))
                    append("  ·  ")
                    append(e.hits)
                }
                textSize = 15f
                if (e.urgent) setTypeface(typeface, Typeface.BOLD)
                setPadding(0, pad, 0, pad)
                setOnClickListener { openUrl(e.url) }
            })
        }
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            toast("No browser found")
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}

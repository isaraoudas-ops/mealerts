package com.mealerts.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.checkbox.MaterialCheckBox
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.textfield.TextInputEditText

class SettingsActivity : AppCompatActivity() {

    private val intervals = longArrayOf(15, 30, 60, 120)

    private lateinit var swEnabled: MaterialSwitch
    private lateinit var spInterval: Spinner
    private lateinit var etKeywords: TextInputEditText
    private lateinit var etUrgent: TextInputEditText
    private lateinit var cbConflict: MaterialCheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        findViewById<MaterialToolbar>(R.id.toolbar).setNavigationOnClickListener { finish() }

        swEnabled = findViewById(R.id.swEnabled)
        spInterval = findViewById(R.id.spInterval)
        etKeywords = findViewById(R.id.etKeywords)
        etUrgent = findViewById(R.id.etUrgent)
        cbConflict = findViewById(R.id.cbConflict)

        spInterval.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            intervals.map { if (it < 60) "Every $it minutes" else "Every ${it / 60} hour(s)" }
        )

        swEnabled.isChecked = Prefs.enabled(this)
        etKeywords.setText(Prefs.keywordsRaw(this))
        etUrgent.setText(Prefs.urgentRaw(this))
        cbConflict.isChecked = Prefs.alertAllConflict(this)
        val idx = intervals.indexOf(Prefs.intervalMin(this))
        spInterval.setSelection(if (idx >= 0) idx else 0)

        swEnabled.setOnCheckedChangeListener { _, on ->
            Prefs.setEnabled(this, on)
            if (on) Scheduler.schedule(this, Prefs.intervalMin(this), replace = true) else Scheduler.cancel(this)
            toast(if (on) "Monitoring on" else "Monitoring paused")
        }

        findViewById<MaterialButton>(R.id.btnSave).setOnClickListener {
            Prefs.saveFilters(this, etKeywords.text.toString(), etUrgent.text.toString(), cbConflict.isChecked)
            Prefs.setIntervalMin(this, intervals[spInterval.selectedItemPosition])
            if (Prefs.enabled(this)) Scheduler.schedule(this, Prefs.intervalMin(this), replace = true)
            toast("Settings saved")
        }

        findViewById<MaterialButton>(R.id.btnReset).setOnClickListener {
            etKeywords.setText(Prefs.DEFAULT_KEYWORDS)
            etUrgent.setText(Prefs.DEFAULT_URGENT)
            toast("Defaults restored. Tap Save to keep them")
        }

        findViewById<MaterialButton>(R.id.btnTest).setOnClickListener {
            if (!Notifier.canPost(this)) {
                toast("Notifications are turned off for ME Alerts in Android settings")
                return@setOnClickListener
            }
            Notifier.createChannels(this)
            Notifier.show(
                this,
                HistoryEntry(
                    "test-alert", "Test alert: notifications are working", FeedFetcher.FEED_URL,
                    "This is what an urgent alert looks like. Tap to open the live map.",
                    System.currentTimeMillis(), true, "test"
                )
            )
        }

        findViewById<MaterialButton>(R.id.btnBattery).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }

        findViewById<MaterialButton>(R.id.btnOpenSite).setOnClickListener {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(FeedFetcher.FEED_URL)))
            } catch (_: Exception) {
            }
        }

        findViewById<MaterialButton>(R.id.btnClear).setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("Clear alert history?")
                .setMessage("All saved alerts will be deleted from this phone.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Clear") { _, _ ->
                    Prefs.clearHistory(this)
                    toast("History cleared")
                }
                .show()
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

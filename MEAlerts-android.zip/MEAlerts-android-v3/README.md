# ME Alerts v3 (Android)

Monitors several Monitor the Situation feeds in the background, sorts every matching story into
**Middle East & Gulf / Eastern Mediterranean / Europe**, and alerts you in three tiers.

## What's new in v3
- **More feeds:** middle-east, israel-gaza, iran, strait-of-hormuz, persian-gulf, red-sea, western-europe, eastern-europe, and black-sea (off by default). You can switch each one on or off in Settings.
- **Eastern Med:** the site has no Eastern Med page, so the app sorts stories into E. Med by their location (Cyprus, Greece, Türkiye, Lebanon, Syria, Israel/Gaza/West Bank, Egypt), whichever feed they come from.
- **Three tiers**, based on the site's severity (S1–S5), its category and your keywords:
  - **ALARM:** an S4+ event; an S3 event with an urgent keyword; or an S3 conflict involving two states (US/Israel/Iran/Russia/NATO). Plays the alarm sound and repeats until you open it. Sounds even during quiet hours.
  - **ALERT:** an S3 conflict or keyword match. Heads-up with sound and vibration.
  - **WATCH:** any other keyword match. Silent, but logged.
- **Upgrades:** if a story's severity goes up later (e.g. it first appears as a short "Latest report" and later gets an S3 rating), you get a new alert marked ▲.
- **Per-region minimum severity.** Europe starts at S2 to cut out domestic politics.
- **Quiet hours** (e.g. 23:00–07:00).
- **Log:** keeps up to 1,500 entries. Each stores the headline, full text, location, severity, category, region, matched keywords and **your note or #tags** (long-press an entry).
- **24-hour trend bar** and **Export log (CSV)** in the ⋮ menu. The CSV opens in Excel with Greek characters intact.
- Each new feed first saves a silent baseline, so enabling a feed doesn't flood you with its old stories.

Updating from v2 keeps your keywords, log and seen list. v3 adds new default keywords for EU threats (bomb threats, sabotage, cyber attacks, warships…). Tap **Defaults → Save** in Settings to apply them.

## Get the APK (GitHub, nothing to install)
1. Upload this folder's contents (including the hidden `.github` folder) to a GitHub repository.
2. **Actions** tab → "Build APK" runs automatically (~4 min). The workflow now uses a pinned Gradle 8.7, so it no longer needs `gradle-wrapper.jar`.
3. Download the **ME-Alerts-v3-apk** artifact, unzip it, and install `app-debug.apk`. It uses the same signing key as v2, so it installs as an update over the old app.

## After installing
1. Allow notifications → Settings → **Send a test alarm**.
2. **Battery optimization settings** → set to "Unrestricted". On Samsung/Xiaomi/Huawei, also allow autostart and background activity.
3. Optional: in Android's notification settings for the app, allow the **Alarm** channel to override Do Not Disturb.

## Limits
- Android runs background checks at most every 15 minutes, and they can be delayed when the phone is in deep sleep.
- The app reads the site's public web pages. If a feed's layout changes, the status card shows which feed failed.

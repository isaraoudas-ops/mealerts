package com.mealerts.app

enum class Tier(val rank: Int, val label: String) {
    NONE(0, ""), WATCH(1, "WATCH"), ALERT(2, "ALERT"), ALARM(3, "ALARM");

    companion object {
        fun of(rank: Int) = values().firstOrNull { it.rank == rank } ?: NONE
    }
}

/**
 * Tiering = site severity (S1–S5) + category + your keywords.
 *  ALARM  S4+ conflict/keyword · S3 + urgent keyword · S3 conflict involving two state actors (US/Israel/Iran/Russia/NATO)
 *  ALERT  S3 conflict or keyword · unrated report with an urgent keyword
 *  WATCH  any other keyword match (or every Conflict event, if enabled)
 */
object Matcher {
    class Rule(val label: String, val regex: Regex)
    data class Result(val tier: Tier, val hits: List<String>)

    private val CONFLICT = Regex("""\bconflict\b""", RegexOption.IGNORE_CASE)
    private val ACTORS = listOf(
        listOf(Regex("""\b(US|U\.S\.)\b"""), Regex("""\b(united states|american|pentagon|centcom)\b""", RegexOption.IGNORE_CASE)),
        listOf(Regex("""\b(israel\w*|idf)\b""", RegexOption.IGNORE_CASE)),
        listOf(Regex("""\b(iran\w*|irgc|tehran)\b""", RegexOption.IGNORE_CASE)),
        listOf(Regex("""\b(russia\w*|kremlin)\b""", RegexOption.IGNORE_CASE)),
        listOf(Regex("""\bNATO\b""")),
    )

    fun compile(words: List<String>): List<Rule> = words.map { w ->
        val pattern = if (w.endsWith("*")) {
            "\\b" + Regex.escape(w.removeSuffix("*").trim())
        } else {
            "\\b" + Regex.escape(w) + "\\b"
        }
        Rule(w, Regex(pattern, RegexOption.IGNORE_CASE))
    }

    fun stateVsState(text: String): Boolean =
        ACTORS.count { group -> group.any { it.containsMatchIn(text) } } >= 2

    fun evaluate(
        item: FeedItem,
        normal: List<Rule>,
        urgent: List<Rule>,
        allConflict: Boolean,
        floor: Int,
        regionOn: Boolean,
    ): Result? {
        if (!regionOn) return null
        val sev = item.severity
        if (sev in 1 until floor) return null

        val text = item.title + " " + item.summary
        val u = urgent.filter { it.regex.containsMatchIn(text) }.map { it.label }
        val n = normal.filter { it.regex.containsMatchIn(text) }.map { it.label }
        val conflict = CONFLICT.containsMatchIn(item.category)
        val kw = u.isNotEmpty() || n.isNotEmpty()
        val svs = conflict && stateVsState(text)

        val tier = when {
            sev >= 4 && (conflict || kw) -> Tier.ALARM
            sev >= 3 && (u.isNotEmpty() || svs) -> Tier.ALARM
            sev >= 3 && (conflict || kw) -> Tier.ALERT
            sev == 0 && u.isNotEmpty() -> Tier.ALERT
            kw -> Tier.WATCH
            allConflict && conflict -> Tier.WATCH
            else -> return null
        }
        val hits = buildList {
            if (svs) add("state-vs-state")
            addAll(u); addAll(n)
            if (isEmpty()) add(if (conflict) "conflict event" else "severity S$sev")
        }
        return Result(tier, hits)
    }
}

package com.mealerts.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat

/** 24 hourly bars, stacked by tier (alarm at the bottom). */
class TrendView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bins = Array(24) { IntArray(4) }
    private val density = resources.displayMetrics.density
    private val tierColors = intArrayOf(
        0,
        ContextCompat.getColor(ctx, R.color.watch),
        ContextCompat.getColor(ctx, R.color.amber),
        ContextCompat.getColor(ctx, R.color.red),
    )
    private val base = ContextCompat.getColor(ctx, R.color.stroke)

    fun setData(entries: List<HistoryEntry>, now: Long) {
        bins.forEach { it.fill(0) }
        entries.forEach { e ->
            val age = ((now - e.time) / 3_600_000L).toInt()
            if (age in 0..23) bins[23 - age][e.tier.coerceIn(1, 3)]++
        }
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val gap = 3 * density
        val w = (width - gap * 23) / 24f
        val baseH = 2 * density
        val usable = height - baseH
        val max = maxOf(1, bins.maxOf { it.sum() })
        for (i in 0 until 24) {
            val x = i * (w + gap)
            paint.color = base
            c.drawRect(x, height - baseH, x + w, height.toFloat(), paint)
            var y = height - baseH
            for (t in intArrayOf(3, 2, 1)) {
                val n = bins[i][t]
                if (n == 0) continue
                val h = n.toFloat() / max * usable
                paint.color = tierColors[t]
                c.drawRect(x, y - h, x + w, y, paint)
                y -= h
            }
        }
    }
}

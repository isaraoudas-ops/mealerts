package com.mealerts.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class HistoryEntry(
    val id: String,
    val title: String,
    val url: String,
    val summary: String,
    val time: Long,
    val tier: Int,
    val hits: String,
    val meta: String = "",
    val region: String = "ME",
    val severity: Int = 0,
    val category: String = "",
    val location: String = "",
    val note: String = "",
    val feed: String = "",
    val upgraded: Boolean = false,
) {
    val urgent: Boolean get() = tier >= Tier.ALARM.rank
}

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("me_alerts", Context.MODE_PRIVATE)

    const val DEFAULT_URGENT =
        "mobiliz*, mobilis*, reservist*, call-up, siren*, air raid*, ballistic, nuclear, " +
        "invasion, invade*, declare* war, declaration of war, preparing for war, prepare* for war, " +
        "state of emergency, home front command, high alert, full-scale, ground operation, " +
        "evacuat*, bomb shelter*, war cabinet, all-out war, exchange fire, exchanged fire"

    const val DEFAULT_KEYWORDS =
        "strike*, airstrike*, air strike*, attack*, missile*, rocket*, drone*, explosion*, blast*, " +
        "clash*, shelling, raid*, intercept*, killed, troops, military, war, warn*, threat*, " +
        "escalat*, offensive, deploy*, carrier, bomber*, mines, tanker*, idf, irgc, hezbollah, " +
        "hamas, houthi*, ansarallah, retaliat*, ceasefire, " +
        "bomb threat*, sabotage, cyber attack*, cyberattack*, fighter jet*, warship*, naval, refinery, pipeline*"

    fun parseList(raw: String): List<String> =
        raw.split(',', '\n').map { it.trim().lowercase() }.filter { it.removeSuffix("*").length >= 2 }.distinct()

    fun enabled(c: Context) = sp(c).getBoolean("enabled", true)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    fun intervalMin(c: Context) = sp(c).getLong("interval", 15L)
    fun setIntervalMin(c: Context, v: Long) = sp(c).edit().putLong("interval", v).apply()

    fun keywordsRaw(c: Context) = sp(c).getString("keywords", DEFAULT_KEYWORDS) ?: DEFAULT_KEYWORDS
    fun urgentRaw(c: Context) = sp(c).getString("urgent", DEFAULT_URGENT) ?: DEFAULT_URGENT
    fun alertAllConflict(c: Context) = sp(c).getBoolean("all_conflict", false)

    fun saveFilters(c: Context, keywords: String, urgent: String, allConflict: Boolean) {
        sp(c).edit()
            .putString("keywords", keywords)
            .putString("urgent", urgent)
            .putBoolean("all_conflict", allConflict)
            .apply()
    }

    // ── Feeds & regions ────────────────────────────────────────────────
    fun feeds(c: Context): Set<String> =
        sp(c).getStringSet("feeds", null)?.toSet()
            ?: FeedFetcher.FEEDS.filter { it.defaultOn }.map { it.slug }.toSet()

    fun setFeeds(c: Context, v: Set<String>) = sp(c).edit().putStringSet("feeds", v.toSet()).apply()

    fun regionOn(c: Context, r: Region) = sp(c).getBoolean("region_on_${r.name}", true)
    fun setRegionOn(c: Context, r: Region, v: Boolean) = sp(c).edit().putBoolean("region_on_${r.name}", v).apply()

    /** Minimum site severity (0 = any). Europe defaults to S2 to cut domestic-politics noise. */
    fun floor(c: Context, r: Region) = sp(c).getInt("floor_${r.name}", if (r == Region.EU) 2 else 0)
    fun setFloor(c: Context, r: Region, v: Int) = sp(c).edit().putInt("floor_${r.name}", v).apply()

    // ── Quiet hours (Alarms always break through) ──────────────────────
    fun quietOn(c: Context) = sp(c).getBoolean("quiet_on", false)
    fun quietStart(c: Context) = sp(c).getInt("quiet_start", 23)
    fun quietEnd(c: Context) = sp(c).getInt("quiet_end", 7)
    fun setQuiet(c: Context, on: Boolean, start: Int, end: Int) =
        sp(c).edit().putBoolean("quiet_on", on).putInt("quiet_start", start).putInt("quiet_end", end).apply()

    fun isQuietNow(c: Context): Boolean {
        if (!quietOn(c)) return false
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val s = quietStart(c)
        val e = quietEnd(c)
        return if (s == e) false else if (s < e) h in s until e else h >= s || h < e
    }

    // ── Seen stories: id → highest tier already handled ────────────────
    fun seenMap(c: Context): MutableMap<String, Int> {
        val p = sp(c)
        val raw = p.getString("seen3", null)
        if (raw == null) {
            // Migrate v2 list: everything already seen counts as fully handled.
            val old = (p.getString("seen", "") ?: "").split('\n').filter { it.isNotEmpty() }
            return old.associateWith { 3 }.toMutableMap()
        }
        val out = LinkedHashMap<String, Int>()
        raw.split('\n').forEach { line ->
            if (line.isEmpty()) return@forEach
            val i = line.lastIndexOf('|')
            if (i < 0) out[line] = 3 else out[line.substring(0, i)] = line.substring(i + 1).toIntOrNull() ?: 3
        }
        return out
    }

    fun putSeen(c: Context, updates: Map<String, Int>) {
        if (updates.isEmpty()) return
        val all = seenMap(c)
        updates.forEach { (k, v) -> all.remove(k); all[k] = v }
        val kept = all.entries.toList().takeLast(3000)
        sp(c).edit().putString("seen3", kept.joinToString("\n") { "${it.key}|${it.value}" }).commit()
    }

    /** Feeds that already have a baseline, so turning a feed on doesn't flood you with its old stories. */
    fun baselined(c: Context): Set<String> {
        val p = sp(c)
        val s = p.getStringSet("baselined", null)
        if (s != null) return s.toSet()
        val hadV2 = (p.getString("seen", "") ?: "").isNotEmpty()
        return if (hadV2) setOf("middle-east") else emptySet()
    }

    fun addBaselined(c: Context, slugs: Set<String>) {
        if (slugs.isEmpty()) return
        sp(c).edit().putStringSet("baselined", baselined(c) + slugs).commit()
    }

    // ── Log ────────────────────────────────────────────────────────────
    fun history(c: Context): List<HistoryEntry> {
        val raw = sp(c).getString("history", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val legacyUrgent = o.optBoolean("urgent")
                HistoryEntry(
                    o.optString("id"), o.optString("title"), o.optString("url"),
                    o.optString("summary"), o.optLong("time"),
                    o.optInt("tier", if (legacyUrgent) 3 else 2),
                    o.optString("hits"), o.optString("meta"),
                    o.optString("region", "ME"), o.optInt("severity", 0),
                    o.optString("category"), o.optString("location"),
                    o.optString("note"), o.optString("feed"), o.optBoolean("upgraded"),
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun writeHistory(c: Context, list: List<HistoryEntry>) {
        val arr = JSONArray()
        list.forEach { e ->
            arr.put(
                JSONObject()
                    .put("id", e.id).put("title", e.title).put("url", e.url)
                    .put("summary", e.summary).put("time", e.time)
                    .put("tier", e.tier).put("urgent", e.urgent).put("hits", e.hits).put("meta", e.meta)
                    .put("region", e.region).put("severity", e.severity)
                    .put("category", e.category).put("location", e.location)
                    .put("note", e.note).put("feed", e.feed).put("upgraded", e.upgraded)
            )
        }
        sp(c).edit().putString("history", arr.toString()).commit()
    }

    /** New entries go on top; an upgraded story replaces its old row but keeps your note. */
    fun addHistory(c: Context, entries: List<HistoryEntry>) {
        val old = history(c)
        val notes = old.associate { it.id to it.note }
        val fresh = entries.map { e -> e.copy(note = notes[e.id].orEmpty().ifEmpty { e.note }) }
        val merged = (fresh + old).distinctBy { it.id }.take(1500)
        writeHistory(c, merged)
    }

    fun setNote(c: Context, id: String, note: String) {
        writeHistory(c, history(c).map { if (it.id == id) it.copy(note = note) else it })
    }

    fun clearHistory(c: Context) {
        sp(c).edit().remove("history").commit()
    }

    fun toCsv(list: List<HistoryEntry>): String {
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
        val sb = StringBuilder("\uFEFF")
        sb.append("time,tier,severity,category,region,location,headline,summary,matched,note,url\n")
        list.forEach { e ->
            sb.append(
                listOf(
                    fmt.format(Date(e.time)), Tier.of(e.tier).label,
                    if (e.severity > 0) "S${e.severity}" else "", e.category,
                    Region.of(e.region).short, e.location, e.title, e.summary, e.hits, e.note, e.url
                ).joinToString(",") { q(it) }
            ).append('\n')
        }
        return sb.toString()
    }

    fun lastCheck(c: Context) = sp(c).getLong("last_check", 0L)
    fun lastError(c: Context): String? = sp(c).getString("last_error", null)

    fun setStatus(c: Context, time: Long, error: String?) {
        sp(c).edit().putLong("last_check", time).putString("last_error", error).commit()
    }
}

package com.mealerts.app

import android.content.Context

object Checker {
    data class Outcome(val parsed: Int, val matched: Int, val notified: Int, val baselineFeeds: Int, val errors: List<String>)

    @Synchronized
    fun run(c: Context): Outcome {
        val now = System.currentTimeMillis()
        try {
            val batch = FeedFetcher.fetchAll(Prefs.feeds(c))
            if (batch.items.isEmpty()) {
                throw IllegalStateException(batch.errors.firstOrNull() ?: "No feeds selected")
            }

            val seen = Prefs.seenMap(c)
            val baselined = Prefs.baselined(c)
            val normal = Matcher.compile(Prefs.parseList(Prefs.keywordsRaw(c)))
            val urgent = Matcher.compile(Prefs.parseList(Prefs.urgentRaw(c)))
            val allConflict = Prefs.alertAllConflict(c)
            val floors = Region.values().associateWith { Prefs.floor(c, it) }
            val regionOn = Region.values().associateWith { Prefs.regionOn(c, it) }

            val seenUpdates = LinkedHashMap<String, Int>()
            val entries = mutableListOf<HistoryEntry>()
            val toNotify = mutableListOf<HistoryEntry>()

            for (item in batch.items) {
                val m = Matcher.evaluate(item, normal, urgent, allConflict, floors.getValue(item.region), regionOn.getValue(item.region))
                val rank = m?.tier?.rank ?: 0
                val prev = seen[item.id]
                if (prev != null && rank <= prev) continue
                seenUpdates[item.id] = rank
                if (m == null) continue

                val e = HistoryEntry(
                    item.id, item.title, item.url, item.summary, now, rank,
                    m.hits.joinToString(", "), item.meta, item.region.name, item.severity,
                    item.category, item.location, "", item.feed, upgraded = prev != null && prev > 0,
                )
                entries += e
                if (item.feed in baselined) toNotify += e
            }

            Prefs.putSeen(c, seenUpdates)
            if (entries.isNotEmpty()) Prefs.addHistory(c, entries)
            val newBaselines = batch.okFeeds - baselined
            Prefs.addBaselined(c, batch.okFeeds)

            if (toNotify.isNotEmpty()) {
                Notifier.createChannels(c)
                val quiet = Prefs.isQuietNow(c)
                toNotify.sortedByDescending { it.tier }.take(10).asReversed().forEach { Notifier.show(c, it, quiet) }
            }

            val err = if (batch.errors.isEmpty()) null
            else "${batch.errors.size} of ${batch.errors.size + batch.okFeeds.size} feeds failed: " + batch.errors.joinToString("; ")
            Prefs.setStatus(c, now, err)
            return Outcome(batch.items.size, entries.size, toNotify.size, newBaselines.size, batch.errors)
        } catch (e: Exception) {
            Prefs.setStatus(c, now, e.message ?: e.javaClass.simpleName)
            throw e
        }
    }
}

package com.mealerts.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.checkbox.MaterialCheckBox
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.textfield.TextInputEditText

class SettingsActivity : AppCompatActivity() {

    private val intervals = longArrayOf(15, 30, 60, 120)
    private val floors = intArrayOf(0, 2, 3, 4)
    private val floorLabels = listOf("Any severity", "S2 and above", "S3 and above", "S4 and above")
    private val hours = (0..23).map { "%02d:00".format(it) }

    private lateinit var swEnabled: MaterialSwitch
    private lateinit var spInterval: Spinner
    private lateinit var etKeywords: TextInputEditText
    private lateinit var etUrgent: TextInputEditText
    private lateinit var cbConflict: MaterialCheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        findViewById<MaterialToolbar>(R.id.toolbar).setNavigationOnClickListener { finish() }

        swEnabled = findViewById(R.id.swEnabled)
        spInterval = findViewById(R.id.spInterval)
        etKeywords = findViewById(R.id.etKeywords)
        etUrgent = findViewById(R.id.etUrgent)
        cbConflict = findViewById(R.id.cbConflict)

        spInterval.adapter = adapterOf(intervals.map { if (it < 60) "Every $it minutes" else "Every ${it / 60} hour(s)" })

        swEnabled.isChecked = Prefs.enabled(this)
        etKeywords.setText(Prefs.keywordsRaw(this))
        etUrgent.setText(Prefs.urgentRaw(this))
        cbConflict.isChecked = Prefs.alertAllConflict(this)
        val idx = intervals.indexOf(Prefs.intervalMin(this))
        spInterval.setSelection(if (idx >= 0) idx else 0)

        swEnabled.setOnCheckedChangeListener { _, on ->
            Prefs.setEnabled(this, on)
            if (on) Scheduler.schedule(this, Prefs.intervalMin(this), replace = true) else Scheduler.cancel(this)
            toast(if (on) "Monitoring on" else "Monitoring paused")
        }

        buildRegions()
        buildFeeds()
        buildQuietHours()

        findViewById<MaterialButton>(R.id.btnSave).setOnClickListener {
            Prefs.saveFilters(this, etKeywords.text.toString(), etUrgent.text.toString(), cbConflict.isChecked)
            Prefs.setIntervalMin(this, intervals[spInterval.selectedItemPosition])
            if (Prefs.enabled(this)) Scheduler.schedule(this, Prefs.intervalMin(this), replace = true)
            toast("Settings saved")
        }

        findViewById<MaterialButton>(R.id.btnReset).setOnClickListener {
            etKeywords.setText(Prefs.DEFAULT_KEYWORDS)
            etUrgent.setText(Prefs.DEFAULT_URGENT)
            toast("Defaults restored. Tap Save to keep them")
        }

        findViewById<MaterialButton>(R.id.btnTest).setOnClickListener {
            if (!Notifier.canPost(this)) {
                toast("Notifications are turned off for ME Alerts in Android settings")
                return@setOnClickListener
            }
            Notifier.createChannels(this)
            Notifier.show(
                this,
                HistoryEntry(
                    "test-alert", "Test alarm: notifications are working", FeedFetcher.FEED_URL,
                    "This is what an ALARM looks like. It repeats until you open or swipe it.",
                    System.currentTimeMillis(), Tier.ALARM.rank, "test",
                    region = Region.ME.name, severity = 4, category = "Conflict", location = "Test",
                ),
                quiet = false,
            )
        }

        findViewById<MaterialButton>(R.id.btnBattery).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }

        findViewById<MaterialButton>(R.id.btnOpenSite).setOnClickListener {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(FeedFetcher.FEED_URL)))
            } catch (_: Exception) {
            }
        }

        findViewById<MaterialButton>(R.id.btnClear).setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("Clear alert history?")
                .setMessage("All saved alerts and notes will be deleted from this phone. Export first if you need them.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Clear") { _, _ ->
                    Prefs.clearHistory(this)
                    toast("History cleared")
                }
                .show()
        }
    }

    private fun buildRegions() {
        val box = findViewById<LinearLayout>(R.id.regionRows)
        Region.values().forEach { r ->
            val row = layoutInflater.inflate(R.layout.row_region, box, false)
            val sw = row.findViewById<MaterialSwitch>(R.id.swRegion)
            val sp = row.findViewById<Spinner>(R.id.spFloor)
            sw.text = r.label
            sw.isChecked = Prefs.regionOn(this, r)
            sw.setOnCheckedChangeListener { _, on -> Prefs.setRegionOn(this, r, on) }
            sp.adapter = adapterOf(floorLabels)
            sp.setSelection(floors.indexOf(Prefs.floor(this, r)).coerceAtLeast(0))
            sp.onPick { Prefs.setFloor(this, r, floors[it]) }
            box.addView(row)
        }
    }

    private fun buildFeeds() {
        val box = findViewById<LinearLayout>(R.id.feedRows)
        val selected = Prefs.feeds(this).toMutableSet()
        FeedFetcher.FEEDS.forEach { f ->
            val cb = MaterialCheckBox(this).apply {
                text = "${f.label}   /${f.slug}"
                isChecked = f.slug in selected
                setTextColor(getColor(R.color.text_primary))
            }
            cb.setOnCheckedChangeListener { v, on ->
                if (on) selected += f.slug else selected -= f.slug
                if (selected.isEmpty()) {
                    selected += f.slug
                    v.isChecked = true
                    toast("Keep at least one feed")
                    return@setOnCheckedChangeListener
                }
                Prefs.setFeeds(this, selected)
            }
            box.addView(cb)
        }
    }

    private fun buildQuietHours() {
        val sw = findViewById<MaterialSwitch>(R.id.swQuiet)
        val spS = findViewById<Spinner>(R.id.spQuietStart)
        val spE = findViewById<Spinner>(R.id.spQuietEnd)
        spS.adapter = adapterOf(hours)
        spE.adapter = adapterOf(hours)
        sw.isChecked = Prefs.quietOn(this)
        spS.setSelection(Prefs.quietStart(this))
        spE.setSelection(Prefs.quietEnd(this))
        val save = { Prefs.setQuiet(this, sw.isChecked, spS.selectedItemPosition, spE.selectedItemPosition) }
        sw.setOnCheckedChangeListener { _, _ -> save() }
        spS.onPick { save() }
        spE.onPick { save() }
    }

    private fun adapterOf(items: List<String>) =
        ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)

    private fun Spinner.onPick(f: (Int) -> Unit) {
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = f(pos)
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

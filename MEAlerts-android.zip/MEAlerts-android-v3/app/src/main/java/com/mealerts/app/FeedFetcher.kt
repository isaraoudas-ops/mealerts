package com.mealerts.app

import org.jsoup.Jsoup

enum class Region(val label: String, val short: String) {
    ME("Middle East & Gulf", "ME"),
    EMED("Eastern Mediterranean", "E.MED"),
    EU("Europe", "EU");

    companion object {
        fun of(s: String) = values().firstOrNull { it.name == s } ?: ME
    }
}

data class Feed(val slug: String, val label: String, val region: Region, val defaultOn: Boolean) {
    val url: String get() = FeedFetcher.BASE + slug
}

/** One story. meta = "S3 · Conflict · Strait of Hormuz"; severity 0 = not given (e.g. "Latest reports" list). */
data class FeedItem(
    val id: String,
    val url: String,
    val title: String,
    val summary: String,
    val meta: String,
    val feed: String,
    val region: Region,
    val severity: Int,
    val category: String,
    val location: String,
)

/**
 * Reads several public Monitor the Situation pages and extracts story links of the form
 * https://monitor-the-situation.com/<page>/<slug>-<hex id>
 *
 * There is no dedicated Eastern Mediterranean page, so E.MED is built by matching each story's
 * location (Cyprus, Greece, Türkiye, Lebanon, Syria, Israel/Gaza/West Bank, Egypt) across all feeds.
 */
object FeedFetcher {
    const val BASE = "https://monitor-the-situation.com/"
    const val FEED_URL = BASE + "middle-east"

    val FEEDS = listOf(
        Feed("middle-east", "Middle East & N. Africa", Region.ME, true),
        Feed("israel-gaza", "Israel & Gaza", Region.EMED, true),
        Feed("iran", "Iran", Region.ME, true),
        Feed("strait-of-hormuz", "Strait of Hormuz", Region.ME, true),
        Feed("persian-gulf", "Persian Gulf", Region.ME, true),
        Feed("red-sea", "Red Sea", Region.ME, true),
        Feed("western-europe", "Western Europe", Region.EU, true),
        Feed("eastern-europe", "Eastern Europe", Region.EU, true),
        Feed("black-sea", "Black Sea", Region.EU, false),
    )

    private val STORY = Regex("""^https://monitor-the-situation\.com/([a-z-]+)/([a-z0-9-]+-[0-9a-f]{6,})$""")
    private val AGO = Regex("""(?:·\s*)?\b\d+\s*[a-zA-Z]{1,7}\s+ago\b\.?""")
    private val SEV = Regex("""^S(\d)$""")
    private val EMED_PLACES = Regex(
        """\b(israel\w*|gaza|west bank|jenin|nablus|ramallah|hebron|tel aviv|jerusalem|haifa|golan|""" +
            """lebanon|lebanese|beirut|tyre|sidon|syria\w*|damascus|homs|latakia|tartus|aleppo|idlib|""" +
            """cyprus|cypriot|nicosia|limassol|larnaca|greece|greek|athens|crete|aegean|""" +
            """turkey|türkiye|turkish|ankara|istanbul|izmir|egypt\w*|sinai|cairo|suez|alexandria|""" +
            """eastern mediterranean|east med)\b""",
        RegexOption.IGNORE_CASE
    )

    data class Batch(val items: List<FeedItem>, val okFeeds: Set<String>, val errors: List<String>)

    fun fetchAll(slugs: Set<String>): Batch {
        val out = LinkedHashMap<String, FeedItem>()
        val ok = mutableSetOf<String>()
        val errors = mutableListOf<String>()
        for (feed in FEEDS.filter { it.slug in slugs }) {
            try {
                val items = fetch(feed)
                if (items.isEmpty()) {
                    errors += "${feed.label}: no stories found (layout may have changed)"
                    continue
                }
                ok += feed.slug
                for (item in items) {
                    val prev = out[item.id]
                    // Keep the copy that carries a severity; the first feed that saw it stays the owner.
                    if (prev == null) out[item.id] = item
                    else if (prev.severity == 0 && item.severity > 0) out[item.id] = item.copy(feed = prev.feed)
                }
            } catch (e: Exception) {
                errors += "${feed.label}: ${e.message ?: e.javaClass.simpleName}"
            }
        }
        return Batch(out.values.toList(), ok, errors)
    }

    fun fetch(feed: Feed): List<FeedItem> {
        val doc = Jsoup.connect(feed.url)
            .userAgent("Mozilla/5.0 (Linux; Android) MEAlerts/3.0")
            .timeout(25_000)
            .maxBodySize(0)
            .get()

        val out = LinkedHashMap<String, FeedItem>()
        for (a in doc.select("a[href]")) {
            val href = a.absUrl("href").substringBefore('#').substringBefore('?').trimEnd('/')
            val id = STORY.matchEntire(href)?.groupValues?.get(2) ?: continue
            if (out.containsKey(id)) continue
            val title = a.text().trim()
            if (title.isEmpty()) continue

            val container = a.parents().firstOrNull { it.tagName() == "li" } ?: a.parent()
            var rest = container?.text()?.trim().orEmpty()
            if (rest.length > 1200) rest = ""
            rest = rest.removePrefix(title).trim().trimStart('—', '–', '-', ' ').trim()

            val (meta, summary) = split(rest)
            val parts = meta.split("·").map { it.trim() }.filter { it.isNotEmpty() }
            val sev = parts.firstOrNull()?.let { SEV.matchEntire(it)?.groupValues?.get(1)?.toIntOrNull() } ?: 0
            val fields = if (sev > 0) parts.drop(1) else parts
            val category = fields.getOrNull(0).orEmpty()
            val location = fields.drop(1).joinToString(", ")

            out[id] = FeedItem(
                id, href, title, summary, meta, feed.slug,
                classify(feed, location, title), sev, category, location
            )
        }
        return out.values.toList()
    }

    fun classify(feed: Feed, location: String, title: String): Region = when {
        EMED_PLACES.containsMatchIn(location) -> Region.EMED
        location.isBlank() && EMED_PLACES.containsMatchIn(title) -> Region.EMED
        else -> feed.region
    }

    /** "S3 · Conflict · Place · 48m ago. Text…" → ("S3 · Conflict · Place", "Text…") */
    fun split(raw: String): Pair<String, String> {
        val m = AGO.find(raw) ?: return "" to raw
        val meta = raw.substring(0, m.range.first).trim().trimEnd('·').trim()
        val summary = raw.substring(m.range.last + 1).trim()
        return meta to summary
    }
}

package com.mealerts.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

object Notifier {
    private const val CH_ALARM = "alarm_v3"
    private const val CH_ALERT = "alert_v3"
    private const val CH_WATCH = "watch_v3"
    private const val CH_QUIET = "quiet_v3"

    fun createChannels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java) ?: return
        listOf("urgent_v1", "normal_v1").forEach { nm.deleteNotificationChannel(it) }

        nm.createNotificationChannel(
            NotificationChannel(CH_ALARM, "Alarm: major escalation", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "State-vs-state strikes, S4+ events, mobilisation, nuclear/ballistic threats. Repeats until opened and sounds during quiet hours."
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 600, 300, 600, 300, 900)
                setSound(
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
                )
                setBypassDnd(true)
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERT, "Alert: S3 conflict", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Severity S3 conflict reports and keyword matches. Sound and vibration."
                enableVibration(true)
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_WATCH, "Watch: lower severity", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Lower-severity matches. Silent, logged."
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_QUIET, "Quiet hours", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Watch and Alert items that arrive during quiet hours."
            }
        )
    }

    fun canPost(c: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun show(c: Context, e: HistoryEntry, quiet: Boolean) {
        if (!canPost(c)) return
        val tier = Tier.of(e.tier)
        val channel = when {
            tier == Tier.ALARM -> CH_ALARM
            quiet -> CH_QUIET
            tier == Tier.ALERT -> CH_ALERT
            else -> CH_WATCH
        }
        val open = Intent(Intent.ACTION_VIEW, Uri.parse(e.url))
        val pi = PendingIntent.getActivity(
            c, e.id.hashCode(), open,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val tag = listOfNotNull(
            Region.of(e.region).short,
            e.severity.takeIf { it > 0 }?.let { "S$it" },
            e.category.ifEmpty { null },
        ).joinToString(" · ")
        val body = e.summary.ifEmpty { e.location.ifEmpty { "Matched: ${e.hits}" } }
        val prefix = (if (e.upgraded) "▲ " else "") + tier.label + " · "
        val color = when (tier) {
            Tier.ALARM -> 0xFFE5484D.toInt()
            Tier.ALERT -> 0xFFF5A524.toInt()
            else -> 0xFF7FA7C9.toInt()
        }
        val b = NotificationCompat.Builder(c, channel)
            .setSmallIcon(R.drawable.ic_stat_alert)
            .setContentTitle(prefix + e.title)
            .setContentText(body)
            .setSubText(tag)
            .setStyle(NotificationCompat.BigTextStyle().bigText("$body\n\n${e.location}\nMatched: ${e.hits}"))
            .setPriority(if (tier.rank >= 2 && !quiet || tier == Tier.ALARM) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_LOW)
            .setCategory(if (tier == Tier.ALARM) NotificationCompat.CATEGORY_ALARM else NotificationCompat.CATEGORY_MESSAGE)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setColor(color)
            .setWhen(e.time)
            .setShowWhen(true)
            .setGroup("tier_${tier.rank}")
        val n = b.build()
        if (tier == Tier.ALARM) n.flags = n.flags or Notification.FLAG_INSISTENT
        try {
            NotificationManagerCompat.from(c).notify(e.id.hashCode(), n)
        } catch (_: SecurityException) {
        }
    }
}

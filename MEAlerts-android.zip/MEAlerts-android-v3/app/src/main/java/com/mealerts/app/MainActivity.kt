package com.mealerts.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.format.DateUtils
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.ChipGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.progressindicator.LinearProgressIndicator
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var statusDot: View
    private lateinit var tvStatus: TextView
    private lateinit var tvLast: TextView
    private lateinit var tvError: TextView
    private lateinit var tvCount: TextView
    private lateinit var tvEmpty: TextView
    private lateinit var tvTrend: TextView
    private lateinit var trend: TrendView
    private lateinit var btnCheck: MaterialButton
    private lateinit var progress: LinearProgressIndicator
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var adapter: AlertAdapter

    private var filter = R.id.chipAll
    private var checking = false

    private val askNotif =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (!granted) toast("Notifications are blocked, so alerts can't appear")
            refresh()
        }

    private val exportCsv =
        registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
            if (uri == null) return@registerForActivityResult
            try {
                contentResolver.openOutputStream(uri)?.use {
                    it.write(Prefs.toCsv(Prefs.history(this)).toByteArray(Charsets.UTF_8))
                }
                toast("Log exported")
            } catch (e: Exception) {
                toast("Export failed: ${e.message}")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById<MaterialToolbar>(R.id.toolbar))
        supportActionBar?.setDisplayShowTitleEnabled(false)
        Notifier.createChannels(this)

        statusDot = findViewById(R.id.statusDot)
        tvStatus = findViewById(R.id.tvStatus)
        tvLast = findViewById(R.id.tvLast)
        tvError = findViewById(R.id.tvError)
        tvCount = findViewById(R.id.tvCount)
        tvEmpty = findViewById(R.id.tvEmpty)
        tvTrend = findViewById(R.id.tvTrend)
        trend = findViewById(R.id.trend)
        btnCheck = findViewById(R.id.btnCheck)
        progress = findViewById(R.id.progress)
        swipe = findViewById(R.id.swipe)

        adapter = AlertAdapter(onOpen = { openUrl(it.url) }, onLong = { actions(it) })
        findViewById<RecyclerView>(R.id.rv).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        swipe.setColorSchemeColors(ContextCompat.getColor(this, R.color.red))
        swipe.setProgressBackgroundColorSchemeColor(ContextCompat.getColor(this, R.color.surface2))
        swipe.setOnRefreshListener { checkNow() }
        btnCheck.setOnClickListener { checkNow() }

        findViewById<ChipGroup>(R.id.chips).setOnCheckedStateChangeListener { _, ids ->
            filter = ids.firstOrNull() ?: R.id.chipAll
            refreshList()
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            askNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        if (Prefs.enabled(this)) {
            Scheduler.schedule(this, Prefs.intervalMin(this), replace = false)
            if (Prefs.lastCheck(this) == 0L) checkNow()
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_settings -> startActivity(Intent(this, SettingsActivity::class.java))
            R.id.action_export -> {
                val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                exportCsv.launch("escalation-log-$day.csv")
            }
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    private fun checkNow() {
        if (checking) return
        checking = true
        btnCheck.isEnabled = false
        btnCheck.text = "Checking…"
        progress.isVisible = true
        thread {
            val msg = try {
                val o = Checker.run(applicationContext)
                buildString {
                    append(
                        when {
                            o.notified > 0 -> "${o.notified} new alert(s)"
                            o.matched > 0 -> "${o.matched} matching stor(ies) logged"
                            else -> "No new matching stories (${o.parsed} checked)"
                        }
                    )
                    if (o.baselineFeeds > 0) append(". Baseline saved for ${o.baselineFeeds} new feed(s)")
                    if (o.errors.isNotEmpty()) append(". ${o.errors.size} feed(s) failed")
                }
            } catch (e: Exception) {
                "Check failed: ${e.message}"
            }
            runOnUiThread {
                if (!isDestroyed) {
                    checking = false
                    btnCheck.isEnabled = true
                    btnCheck.text = "Check now"
                    progress.isVisible = false
                    swipe.isRefreshing = false
                    toast(msg)
                    refresh()
                }
            }
        }
    }

    private fun refresh() {
        val on = Prefs.enabled(this)
        statusDot.backgroundTintList = ColorStateList.valueOf(
            ContextCompat.getColor(this, if (on) R.color.green else R.color.slate)
        )
        val feeds = Prefs.feeds(this).size
        val quiet = if (Prefs.isQuietNow(this)) " · quiet hours" else ""
        tvStatus.text = if (on) "Monitoring $feeds feeds · every ${formatInterval(Prefs.intervalMin(this))}$quiet"
        else "Monitoring paused"

        val last = Prefs.lastCheck(this)
        tvLast.text = if (last == 0L) "Not checked yet"
        else "Last check ${DateUtils.getRelativeTimeSpanString(last, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS)}"

        val problems = mutableListOf<String>()
        Prefs.lastError(this)?.let { problems += it }
        if (!Notifier.canPost(this)) problems += "Notifications are turned off for this app"
        tvError.text = problems.joinToString("\n")
        tvError.isVisible = problems.isNotEmpty()

        refreshList()
    }

    private fun refreshList() {
        val all = Prefs.history(this)
        val now = System.currentTimeMillis()
        val day = all.filter { now - it.time < DateUtils.DAY_IN_MILLIS }
        trend.setData(day, now)
        tvTrend.text = "24h  ·  ${day.count { it.tier == 3 }} alarm  ·  ${day.count { it.tier == 2 }} alert  ·  ${day.count { it.tier == 1 }} watch"

        val (label, shown) = when (filter) {
            R.id.chipAlarm -> "Alarms" to all.filter { it.tier >= 3 }
            R.id.chipME -> "Middle East" to all.filter { it.region == Region.ME.name }
            R.id.chipEMED -> "E. Mediterranean" to all.filter { it.region == Region.EMED.name }
            R.id.chipEU -> "Europe" to all.filter { it.region == Region.EU.name }
            else -> "Log" to all
        }
        adapter.submit(shown)
        tvCount.text = "$label (${shown.size})"
        tvEmpty.text = if (filter == R.id.chipAll) "No matching alerts yet.\nPull down or tap Check now." else "Nothing logged here yet."
        tvEmpty.isVisible = shown.isEmpty()
    }

    private fun actions(e: HistoryEntry) {
        MaterialAlertDialogBuilder(this)
            .setTitle(e.title)
            .setItems(arrayOf(if (e.note.isEmpty()) "Add note / #tag" else "Edit note / #tag", "Share", "Open source")) { _, i ->
                when (i) {
                    0 -> editNote(e)
                    1 -> share(e)
                    2 -> openUrl(e.url)
                }
            }
            .show()
    }

    private fun editNote(e: HistoryEntry) {
        val input = EditText(this).apply {
            setText(e.note)
            hint = "e.g. 3rd mine incident this week #shipping"
            setSelection(text.length)
        }
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = FrameLayout(this).apply { setPadding(pad, pad / 2, pad, 0); addView(input) }
        MaterialAlertDialogBuilder(this)
            .setTitle("Note")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                Prefs.setNote(this, e.id, input.text.toString().trim())
                refreshList()
            }
            .show()
    }

    private fun formatInterval(min: Long) = if (min < 60) "$min min" else "${min / 60} h"

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            toast("No browser found")
        }
    }

    private fun share(e: HistoryEntry) {
        val text = buildString {
            append("[").append(Tier.of(e.tier).label).append("] ").append(e.title)
            if (e.location.isNotEmpty()) append("\n").append(e.location)
            if (e.summary.isNotEmpty()) append("\n\n").append(e.summary)
            if (e.note.isNotEmpty()) append("\n\nNote: ").append(e.note)
            append("\n\n").append(e.url)
        }
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        startActivity(Intent.createChooser(send, "Share alert"))
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
